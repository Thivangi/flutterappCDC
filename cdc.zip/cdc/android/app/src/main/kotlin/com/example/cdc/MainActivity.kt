package com.example.cdc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
