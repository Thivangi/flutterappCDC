import 'package:cdc/health.dart';
import 'package:cdc/map.dart';
import 'package:cdc/stats.dart';
import 'package:cdc/test.dart';
import 'package:cdc/vaccine.dart';
import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  Home({Key key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int _currentIndex = 0;

  static List<Widget> _widgetOptions = [
    Map(),
    Test(),
    Vaccine(),
    Health(),
    Stats(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlue.shade400,
        title: Container(
          child:
              Image.asset("assets/images/bsafe3.png", width: 100, height: 100),
        ),
        actions: [
          Padding(
              padding: EdgeInsets.only(right: 20.0),
              child: Icon(Icons.settings))
        ],
      ),
      body: _widgetOptions[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (int value) {
          print(value);

          setState(() {
            _currentIndex = value;
          });
        },
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blue.shade400,
        selectedItemColor: Colors.amber,
        items: [
          BottomNavigationBarItem(
            icon: new Icon(Icons.map_outlined),
            title: new Text('Map'),
          ),
          BottomNavigationBarItem(
            icon: new Icon(Icons.coronavirus_outlined),
            title: new Text('Test'),
          ),
          BottomNavigationBarItem(
            icon: new Icon(Icons.medical_services),
            title: new Text('Vaccine'),
          ),
          BottomNavigationBarItem(
            icon: new Icon(Icons.favorite),
            title: new Text('Health'),
          ),
          BottomNavigationBarItem(
              icon: Icon(Icons.bar_chart), title: Text('Stats'))
        ],
      ),
    );
  }
}
