import 'package:cdc/health.dart';
import 'package:cdc/home.dart';
import 'package:cdc/map.dart';

import 'package:cdc/phischedulevaccine.dart';
import 'package:cdc/phitestdetails.dart';
import 'package:cdc/stats.dart';
import 'package:cdc/test.dart';
import 'package:cdc/testresults.dart';
import 'package:cdc/vaccine.dart';
import 'package:cdc/vaccinestatus.dart';
import 'package:flutter/material.dart';

class Phihomepage extends StatefulWidget {
  Phihomepage({Key key}) : super(key: key);

  @override
  _PhihomepageState createState() => _PhihomepageState();
}

class _PhihomepageState extends State<Phihomepage> {
  int _currentIndex = 0;

  static List<Widget> _widgetOptions = [
    Phitestdetails(),
    Testresults(),
    Phivaccination(),
    Vaccinestatus(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _widgetOptions[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (int value) {
          print(value);

          setState(() {
            _currentIndex = value;
          });
        },
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blue.shade400,
        selectedItemColor: Colors.amber,
        items: [
          BottomNavigationBarItem(
            icon: new Icon(Icons.map),
            title: new Text('Test Details'),
          ),
          BottomNavigationBarItem(
            icon: new Icon(Icons.coronavirus_outlined),
            title: new Text('Test results'),
          ),
          BottomNavigationBarItem(
            icon: new Icon(Icons.calendar_today),
            title: new Text('Schedule'),
          ),
          BottomNavigationBarItem(
              icon: Icon(Icons.favorite), title: Text('status'))
        ],
      ),
    );
  }
}
