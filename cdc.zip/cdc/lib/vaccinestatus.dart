import 'package:flutter/material.dart';

class Vaccinestatus extends StatefulWidget {
  Vaccinestatus({Key key}) : super(key: key);

  @override
  _VaccinestatusState createState() => _VaccinestatusState();
}

class _VaccinestatusState extends State<Vaccinestatus> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.lightBlue.shade400,
          title: Container(
            child: Image.asset("assets/images/bsafe3.png",
                width: 100, height: 100),
          ),
          actions: [
            Padding(
                padding: EdgeInsets.only(right: 20.0),
                child: Icon(Icons.settings))
          ],
        ),
        body: SafeArea(
          child: Container(
            padding: EdgeInsets.only(left: 15, right: 15, top: 60),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Vaccine status",
                    style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        color: Colors.blue),
                  ),
                  SizedBox(
                    height: 55,
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      TextField(
                        decoration: InputDecoration(
                          labelText: "National ID",
                          labelStyle:
                              TextStyle(fontSize: 15, color: Colors.blueGrey),
                          enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide:
                                  BorderSide(color: Colors.blue.shade200)),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide:
                                  BorderSide(color: Colors.blue.shade500)),
                        ),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      TextField(
                        decoration: InputDecoration(
                          labelText: "Vaccination type",
                          labelStyle:
                              TextStyle(fontSize: 15, color: Colors.blueGrey),
                          enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide:
                                  BorderSide(color: Colors.blue.shade200)),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide:
                                  BorderSide(color: Colors.blue.shade500)),
                        ),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      SizedBox(
                        height: 30,
                      ),
                      Container(
                        height: 50,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            color: Colors.blue,
                            borderRadius: BorderRadius.circular(5)),
                        child: GestureDetector(
                          child: FlatButton(
                            onPressed: () {},
                            child: Text("vaccinated",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold)),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
        ));
  }
}
