import 'package:cdc/home.dart';

import 'package:cdc/login.dart';

import 'package:cdc/phihomepage.dart';
import 'package:cdc/phischedulevaccine.dart';
import 'package:cdc/phitestdetails.dart';

import 'package:cdc/register.dart';
import 'package:cdc/start_screen.dart';
import 'package:cdc/testresults.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: Phihomepage(),
    );
  }
}
